module.exports = {
    about(req, res) {
        res.render('about');
    }
};