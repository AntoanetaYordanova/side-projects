import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-not-found-page',
  templateUrl: './page-not-found-page.component.html',
  styleUrls: ['./page-not-found-page.component.css']
})
export class PageNotFoundPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
